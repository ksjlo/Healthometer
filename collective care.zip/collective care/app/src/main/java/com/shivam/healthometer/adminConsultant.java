package com.shivam.healthometer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class adminConsultant extends AppCompatActivity {

    Button sub;
    TextView bmi,dislike,diet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_consultant);

        sub = findViewById(R.id.btnsend1);
        bmi = findViewById(R.id.etbmi1);
        dislike = findViewById(R.id.etdislike1);
        diet = findViewById(R.id.tvdietPrint1);


        String e = getIntent().getStringExtra("bmi1");
        bmi.setText(e);
        String s = getIntent().getStringExtra("dis");
        dislike.setText(s);

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String s = diet.getText().toString();
                Intent intent = new Intent(adminConsultant.this,consultant.class);
                intent.putExtra("diet",s);
                startActivity(intent);
            }
        });
    }
}