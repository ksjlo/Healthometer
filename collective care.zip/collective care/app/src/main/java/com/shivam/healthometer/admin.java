package com.shivam.healthometer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class admin extends AppCompatActivity {

    ImageView backarrow;

    TextView user,code;
    Button  ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        backarrow = findViewById(R.id.backArrow);
        user = findViewById(R.id.etuser);
        code = findViewById(R.id.etcode);
        ad = findViewById(R.id.btnadmin);

        getSupportActionBar().hide();

        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(admin.this, dietCategory.class));
            }
        });


        ad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(code.getText().toString().equals("shivam")
                        && user.getText().toString().equals("krishan"))
                {
                    startActivity(new Intent(admin.this,adminConsultant.class));
                }
                else{
                    Toast.makeText(admin.this, "User Name and Password Incorrect.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}