package com.shivam.healthometer;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class consultant extends AppCompatActivity {

    Button sub;
    TextView bmi,dislike,diet;
    ImageView backarrow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultant);

        backarrow = findViewById(R.id.backArrow);
        sub = findViewById(R.id.btnsend);
        bmi = findViewById(R.id.etbmi);
        dislike = findViewById(R.id.etdislike);
        diet = findViewById(R.id.tvdietPrint);

        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(consultant.this, dashboard.class));
            }
        });

        String e = getIntent().getStringExtra("bmi");
        bmi.setText(e);
//        String s = getIntent().getStringExtra("diet");
//        diet.setText(s);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                getSupportActionBar().hide();

                String b = bmi.getText().toString();
                String d = dislike.getText().toString();
                Intent intent = new Intent(consultant.this,adminConsultant.class);
                intent.putExtra("bmi1",b);
                intent.putExtra("dis",d);
                Toast.makeText(consultant.this, "wait for a diet", Toast.LENGTH_LONG).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        String x = dislike.getText().toString();
                        String s = "\n \n  5egg \n 100g chicken \n 1 bowl curd \n" +
                                " dal & 2chapati \n 1cup oats \n Peanut Butter \n" +
                                " 100g Paneer \n 20g Soy Chunks & 50g fish";

                            s = s.replaceAll(x,"");
                            s = s.trim();

                        diet.setText(s);
                    }
                },5000);
            }
        });

    }

}